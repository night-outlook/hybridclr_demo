using System.Collections.Generic;
public class AOTGenericReferences : UnityEngine.MonoBehaviour
{

	// {{ AOT assemblies
	public static readonly IReadOnlyList<string> PatchedAOTAssemblyList = new List<string>
	{
		"mscorlib.dll",
	};
	// }}

	// {{ constraint implement type
	// }} 

	// {{ AOT generic types
	// System.Collections.Generic.IEnumerable<int>
	// System.Collections.Generic.IEnumerator<int>
	// System.Collections.Generic.IEnumerator<object>
	// System.Collections.Generic.List<object>
	// System.Func<int,object>
	// System.Nullable<int>
	// System.Runtime.CompilerServices.AsyncTaskMethodBuilder<object>
	// }}

	public void RefMethods()
	{
		// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder.AwaitUnsafeOnCompleted<System.Runtime.CompilerServices.TaskAwaiter,AssemblyA.Contracts.M06ExecutionWitness.<CancelledAsync>d__34>(System.Runtime.CompilerServices.TaskAwaiter&,AssemblyA.Contracts.M06ExecutionWitness.<CancelledAsync>d__34&)
		// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder.AwaitUnsafeOnCompleted<System.Runtime.CompilerServices.TaskAwaiter,AssemblyA.Implementation.Extensibility.M06ExecutionWitness.<CancelledAsync>d__34>(System.Runtime.CompilerServices.TaskAwaiter&,AssemblyA.Implementation.Extensibility.M06ExecutionWitness.<CancelledAsync>d__34&)
		// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder.AwaitUnsafeOnCompleted<System.Runtime.CompilerServices.TaskAwaiter,AssemblyA.Implementation.Internal.M06ExecutionWitness.<CancelledAsync>d__36>(System.Runtime.CompilerServices.TaskAwaiter&,AssemblyA.Implementation.Internal.M06ExecutionWitness.<CancelledAsync>d__36&)
		// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder.AwaitUnsafeOnCompleted<System.Runtime.CompilerServices.TaskAwaiter,AssemblyShadowDemo.Consumers.ContractsM06ExecutionWitness.<CancelledAsync>d__36>(System.Runtime.CompilerServices.TaskAwaiter&,AssemblyShadowDemo.Consumers.ContractsM06ExecutionWitness.<CancelledAsync>d__36&)
		// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder.AwaitUnsafeOnCompleted<System.Runtime.CompilerServices.TaskAwaiter,AssemblyShadowDemo.Consumers.ExtensibilityM06ExecutionWitness.<CancelledAsync>d__37>(System.Runtime.CompilerServices.TaskAwaiter&,AssemblyShadowDemo.Consumers.ExtensibilityM06ExecutionWitness.<CancelledAsync>d__37&)
		// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder.AwaitUnsafeOnCompleted<System.Runtime.CompilerServices.YieldAwaitable.YieldAwaiter,AssemblyA.Contracts.M06ExecutionWitness.<ThrowAsync>d__35>(System.Runtime.CompilerServices.YieldAwaitable.YieldAwaiter&,AssemblyA.Contracts.M06ExecutionWitness.<ThrowAsync>d__35&)
		// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder.AwaitUnsafeOnCompleted<System.Runtime.CompilerServices.YieldAwaitable.YieldAwaiter,AssemblyA.Implementation.Extensibility.M06ExecutionWitness.<ThrowAsync>d__35>(System.Runtime.CompilerServices.YieldAwaitable.YieldAwaiter&,AssemblyA.Implementation.Extensibility.M06ExecutionWitness.<ThrowAsync>d__35&)
		// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder.AwaitUnsafeOnCompleted<System.Runtime.CompilerServices.YieldAwaitable.YieldAwaiter,AssemblyA.Implementation.Internal.M06ExecutionWitness.<ThrowAsync>d__37>(System.Runtime.CompilerServices.YieldAwaitable.YieldAwaiter&,AssemblyA.Implementation.Internal.M06ExecutionWitness.<ThrowAsync>d__37&)
		// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder.AwaitUnsafeOnCompleted<System.Runtime.CompilerServices.YieldAwaitable.YieldAwaiter,AssemblyShadowDemo.Consumers.ContractsM06ExecutionWitness.<ThrowAsync>d__37>(System.Runtime.CompilerServices.YieldAwaitable.YieldAwaiter&,AssemblyShadowDemo.Consumers.ContractsM06ExecutionWitness.<ThrowAsync>d__37&)
		// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder.AwaitUnsafeOnCompleted<System.Runtime.CompilerServices.YieldAwaitable.YieldAwaiter,AssemblyShadowDemo.Consumers.ExtensibilityM06ExecutionWitness.<ThrowAsync>d__38>(System.Runtime.CompilerServices.YieldAwaitable.YieldAwaiter&,AssemblyShadowDemo.Consumers.ExtensibilityM06ExecutionWitness.<ThrowAsync>d__38&)
		// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder<object>.AwaitUnsafeOnCompleted<System.Runtime.CompilerServices.TaskAwaiter,AssemblyA.Contracts.M06ExecutionWitness.<RunAsync>d__19>(System.Runtime.CompilerServices.TaskAwaiter&,AssemblyA.Contracts.M06ExecutionWitness.<RunAsync>d__19&)
		// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder<object>.AwaitUnsafeOnCompleted<System.Runtime.CompilerServices.TaskAwaiter,AssemblyA.Implementation.Extensibility.M06ExecutionWitness.<RunAsync>d__19>(System.Runtime.CompilerServices.TaskAwaiter&,AssemblyA.Implementation.Extensibility.M06ExecutionWitness.<RunAsync>d__19&)
		// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder<object>.AwaitUnsafeOnCompleted<System.Runtime.CompilerServices.TaskAwaiter,AssemblyA.Implementation.Internal.M06ExecutionWitness.<RunAsync>d__19>(System.Runtime.CompilerServices.TaskAwaiter&,AssemblyA.Implementation.Internal.M06ExecutionWitness.<RunAsync>d__19&)
		// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder<object>.AwaitUnsafeOnCompleted<System.Runtime.CompilerServices.TaskAwaiter,AssemblyShadowDemo.Consumers.ContractsM06ExecutionWitness.<RunAsync>d__19>(System.Runtime.CompilerServices.TaskAwaiter&,AssemblyShadowDemo.Consumers.ContractsM06ExecutionWitness.<RunAsync>d__19&)
		// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder<object>.AwaitUnsafeOnCompleted<System.Runtime.CompilerServices.TaskAwaiter,AssemblyShadowDemo.Consumers.ExtensibilityM06ExecutionWitness.<RunAsync>d__19>(System.Runtime.CompilerServices.TaskAwaiter&,AssemblyShadowDemo.Consumers.ExtensibilityM06ExecutionWitness.<RunAsync>d__19&)
		// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder.Start<AssemblyA.Contracts.M06ExecutionWitness.<CancelledAsync>d__34>(AssemblyA.Contracts.M06ExecutionWitness.<CancelledAsync>d__34&)
		// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder.Start<AssemblyA.Contracts.M06ExecutionWitness.<ThrowAsync>d__35>(AssemblyA.Contracts.M06ExecutionWitness.<ThrowAsync>d__35&)
		// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder.Start<AssemblyA.Implementation.Extensibility.M06ExecutionWitness.<CancelledAsync>d__34>(AssemblyA.Implementation.Extensibility.M06ExecutionWitness.<CancelledAsync>d__34&)
		// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder.Start<AssemblyA.Implementation.Extensibility.M06ExecutionWitness.<ThrowAsync>d__35>(AssemblyA.Implementation.Extensibility.M06ExecutionWitness.<ThrowAsync>d__35&)
		// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder.Start<AssemblyA.Implementation.Internal.M06ExecutionWitness.<CancelledAsync>d__36>(AssemblyA.Implementation.Internal.M06ExecutionWitness.<CancelledAsync>d__36&)
		// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder.Start<AssemblyA.Implementation.Internal.M06ExecutionWitness.<ThrowAsync>d__37>(AssemblyA.Implementation.Internal.M06ExecutionWitness.<ThrowAsync>d__37&)
		// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder.Start<AssemblyShadowDemo.Consumers.ContractsM06ExecutionWitness.<CancelledAsync>d__36>(AssemblyShadowDemo.Consumers.ContractsM06ExecutionWitness.<CancelledAsync>d__36&)
		// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder.Start<AssemblyShadowDemo.Consumers.ContractsM06ExecutionWitness.<ThrowAsync>d__37>(AssemblyShadowDemo.Consumers.ContractsM06ExecutionWitness.<ThrowAsync>d__37&)
		// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder.Start<AssemblyShadowDemo.Consumers.ExtensibilityM06ExecutionWitness.<CancelledAsync>d__37>(AssemblyShadowDemo.Consumers.ExtensibilityM06ExecutionWitness.<CancelledAsync>d__37&)
		// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder.Start<AssemblyShadowDemo.Consumers.ExtensibilityM06ExecutionWitness.<ThrowAsync>d__38>(AssemblyShadowDemo.Consumers.ExtensibilityM06ExecutionWitness.<ThrowAsync>d__38&)
		// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder<object>.Start<AssemblyA.Contracts.M06ExecutionWitness.<RunAsync>d__19>(AssemblyA.Contracts.M06ExecutionWitness.<RunAsync>d__19&)
		// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder<object>.Start<AssemblyA.Implementation.Extensibility.M06ExecutionWitness.<RunAsync>d__19>(AssemblyA.Implementation.Extensibility.M06ExecutionWitness.<RunAsync>d__19&)
		// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder<object>.Start<AssemblyA.Implementation.Internal.M06ExecutionWitness.<RunAsync>d__19>(AssemblyA.Implementation.Internal.M06ExecutionWitness.<RunAsync>d__19&)
		// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder<object>.Start<AssemblyShadowDemo.Consumers.ContractsM06ExecutionWitness.<RunAsync>d__19>(AssemblyShadowDemo.Consumers.ContractsM06ExecutionWitness.<RunAsync>d__19&)
		// System.Void System.Runtime.CompilerServices.AsyncTaskMethodBuilder<object>.Start<AssemblyShadowDemo.Consumers.ExtensibilityM06ExecutionWitness.<RunAsync>d__19>(AssemblyShadowDemo.Consumers.ExtensibilityM06ExecutionWitness.<RunAsync>d__19&)
	}
}